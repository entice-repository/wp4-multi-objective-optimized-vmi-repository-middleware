*****************************************************
** Pre-requisite for the Interoperability Software **
*****************************************************
1). Java:
	java version "1.8.0_111"
	Java(TM) SE Runtime Environment (build 1.8.0_111-b14)
	Java HotSpot(TM) 64-Bit Server VM (build 25.111-b14, mixed mode)

2)  QEMU: Full installation : qemu-system-x86_64


*****************************************************
** Usage of Interoperability Software : *************
*****************************************************

1) To run the software, Run the jar file :
	java -jar VMIInteroperability.jar

2) Follow instructions further :

	(a) Enter the input image format without quotes : "raw" or "vmdk" or "vdi" or "qcow2" 
	(b) Enter the output image format without quotes : "raw" or "vmdk" or "vdi" or "qcow2"
	(c) Enter the input image path : /home/user/Downloads/image1.qcow2
	(d) Enter the output image path : /home/user/Downloads/image1.vmdk


3) Get the converted VMI as required.
